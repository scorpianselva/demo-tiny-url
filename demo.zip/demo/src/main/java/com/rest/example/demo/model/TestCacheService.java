package com.rest.example.demo.model;



import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;

@Service
public class TestCacheService {
	
	
	public static final String MY_KEY = "mykey";
	Logger _log = (Logger)LoggerFactory.getLogger(TestCacheService.class);	
	
	 @Cacheable(cacheNames = "myCache",key = "#root.target.MY_KEY")
	    public String cacheThis(){
		 	_log.error("Returning NOT from cache!");
	        return "this Is it";
	    }

}


package com.rest.example.demo.model;

import java.util.Date;

import javax.persistence.NoResultException;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
//import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rest.example.demo.exception.UrlNotFoundException;

import ch.qos.logback.classic.Logger;
import io.seruco.encoding.base62.Base62;

@Component
public class TinyURLService implements ITinyURLService {
	
	@Autowired
	private TinyURLDao tinyURLDao;
	
	Base62 base62 = Base62.createInstance();

	Logger _log = (Logger)LoggerFactory.getLogger(TinyURLService.class);

	@Transactional
	@Override
	public String generateTinyURL(String longURL) {
	  try {	
		FlintoTinyURL tinyURL = new FlintoTinyURL();
		tinyURL.setLongURL(longURL);
		tinyURL.setUpdatedOn(new Date());
		_log.error("heyyyy output -->><<-- "+tinyURLDao.getLargestBarcodeNumber().toString());
		final byte[] encoded = base62.encode(tinyURLDao.getLargestBarcodeNumber().toString().getBytes());
		String shortURL = new String(encoded); 
		tinyURL.setShortURL(shortURL);
		tinyURLDao.save(tinyURL);
		return shortURL;
	  }catch(Exception ex){
		  _log.error("Exception while ");
	  }
	  return null;
	}

	@Override
	public String getLongURL(String shortURL) throws Exception {
		if(StringUtils.isEmpty(shortURL) ||  shortURL == null) {
			throw new Exception("invalid shortURL");
		}
		try {
			FlintoTinyURL tinURLObj = tinyURLDao.findByColumn("shortURL", shortURL);
			return tinURLObj.getLongURL();
		}catch (NoResultException ne) {
			throw new UrlNotFoundException("Given url not available");
		}
		
	}
	
	
}

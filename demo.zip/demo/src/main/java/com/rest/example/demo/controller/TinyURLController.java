package com.rest.example.demo.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rest.example.demo.exception.UrlNotFoundException;
import com.rest.example.demo.model.ITinyURLService;
import com.rest.example.demo.model.JSONResponse;



@RestController
public class TinyURLController {
	
	@Autowired
	private ITinyURLService tinyURLService; 

	@RequestMapping(value = "/create-tinyUrl",method = RequestMethod.GET)
	public JSONResponse generateTinyUrl(@RequestParam String longURL,HttpServletRequest request, HttpServletResponse response) {
		JSONResponse jsonResponse = new JSONResponse();
		String shortURL = tinyURLService.generateTinyURL(longURL);
		if(StringUtils.isEmpty(shortURL) || shortURL == null) {
			jsonResponse.setSuccess(Boolean.FALSE);
			jsonResponse.setMessage("Unable to generate ShortURL");
		}else {
			jsonResponse.setSuccess(Boolean.TRUE);
			jsonResponse.setResult(shortURL);
			jsonResponse.setMessage("ShortURL generated successfully");
			
		}
		return jsonResponse;
	}
	
	@RequestMapping(value = "/{shotURL}",method = RequestMethod.GET)
	public JSONResponse covertToOriginal(@PathVariable String shotURL,HttpServletRequest request,
										HttpServletResponse response) throws Exception{
		String longURL = tinyURLService.getLongURL(shotURL);
		if(StringUtils.isEmpty(longURL) || longURL == null)
			throw new UrlNotFoundException("Given url not available");
		else
			response.sendRedirect("https://flintobox.com/"+longURL);

		return null;
	}
	
}

package com.rest.example.demo;

import java.util.Locale;
import java.util.ResourceBundle;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.rest.example.demo.model.TestCacheService;

import ch.qos.logback.classic.Logger;

@SpringBootApplication
@EnableCaching
public class DemoApplication  implements CommandLineRunner{
	
	@Autowired
	TestCacheService testCacheService;
	
	Logger _log = (Logger)LoggerFactory.getLogger(DemoApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
	
	@Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver localResolver = new SessionLocaleResolver();
		localResolver.setDefaultLocale(Locale.US);
		return localResolver;
	}
	
	@Bean
	public ResourceBundleMessageSource bundleMessageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasename("messages");
		return messageSource;
	}

	@Override
	public void run(String... args) throws Exception {
		
	    String firstString = testCacheService.cacheThis();
	    _log.error("First: {}", firstString);
	    String secondString = testCacheService.cacheThis();
	    _log.error("Second: {}", secondString);

	}

}

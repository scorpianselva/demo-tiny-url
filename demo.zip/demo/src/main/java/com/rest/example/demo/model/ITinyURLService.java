package com.rest.example.demo.model;

public interface ITinyURLService {

	public String generateTinyURL(String longurl);
	
	public String getLongURL(String shortURL)throws Exception; 
	
}

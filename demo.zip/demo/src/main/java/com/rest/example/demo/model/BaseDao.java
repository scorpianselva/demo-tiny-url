package com.rest.example.demo.model;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

@Component
public abstract class BaseDao<T extends Domain> {
	

	@PersistenceContext
    private EntityManager entityManger;
    //The class name of the Generic Type T.
    private Class<T> clazz;
    
    public BaseDao() {
    	ParameterizedType genericSuperclass = (ParameterizedType) getClass().getGenericSuperclass();
    	Class<T> class1 = (Class<T>) genericSuperclass.getActualTypeArguments()[0];
		this.clazz = class1;
    
    }

    //getEntityManager
    public EntityManager getEntityManger() {
        return entityManger;
    }

    /**
     * Creates or updates the Persistent entity. If the @Id field present, then
     * it updates else creates.
     *
     * @param entity
     */
    public void save(Domain entity) {
        this.entityManger.persist(entity);
    }

    /**
     * Deletes the entity if the id is present.
     *
     * @param entity
     */
    public void delete(Domain entity) {
        this.entityManger.remove(entity);
    }
    
    /*
     * Refreshes the entity.
     * @param entity
     */
    public void merge(Domain entity) {
        this.entityManger.merge(entity);
    }
    
     /*
     * Removes entity from session.
     * @param entity
     */
    public void detach(Domain entity) {
        this.entityManger.detach(entity);
    }

    /**
     * Retrieves all the values from the Table
     *
     * @return List<T>
     */
    public List<T> findAll() {
    	return this.entityManger.createQuery(" select c from " + clazz.getName() + " c ").getResultList();
    }
    
    public T findById(Object idValue) {
    	return (T) this.entityManger.find(clazz, idValue);
    }
    
    /**
     * Retrieves the entity by column and it value.
     * Always return a single result or throws exception
     *
     * @return List<T>
     */
    public T findByColumn(String columnName, Object columnValue) {
        StringBuilder sb = new StringBuilder();
        sb.append("from ").append(clazz.getName()).append(" where ").append(columnName).append(" = :columnValue");
        Query query = this.entityManger.createQuery(sb.toString());
        query.setParameter("columnValue", columnValue);
        return (T) query.getSingleResult();


    }
    
    /**
     * Retrieves the entity by column and it value.
     * Always return a single result or throws exception
     *
     * @return List<T>
     */
    public List<T> findMultipleByColumn(String columnName, Object columnValue) {
        StringBuilder sb = new StringBuilder();
        sb.append("from ").append(clazz.getName()).append(" where ").append(columnName).append(" = :columnValue");
        Query query = this.entityManger.createQuery(sb.toString());
        query.setParameter("columnValue", columnValue);
        return (List<T>) query.getResultList();

    }
    

}
